/*******************************************************************************
* File Name: RainSense.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_RainSense_ALIASES_H) /* Pins RainSense_ALIASES_H */
#define CY_PINS_RainSense_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define RainSense_0			(RainSense__0__PC)
#define RainSense_0_PS		(RainSense__0__PS)
#define RainSense_0_PC		(RainSense__0__PC)
#define RainSense_0_DR		(RainSense__0__DR)
#define RainSense_0_SHIFT	(RainSense__0__SHIFT)
#define RainSense_0_INTR	((uint16)((uint16)0x0003u << (RainSense__0__SHIFT*2u)))

#define RainSense_INTR_ALL	 ((uint16)(RainSense_0_INTR))


#endif /* End Pins RainSense_ALIASES_H */


/* [] END OF FILE */
