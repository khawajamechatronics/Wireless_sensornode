/*******************************************************************************
* File Name: RAIN_interrupt.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_RAIN_interrupt_H)
#define CY_ISR_RAIN_interrupt_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void RAIN_interrupt_Start(void);
void RAIN_interrupt_StartEx(cyisraddress address);
void RAIN_interrupt_Stop(void);

CY_ISR_PROTO(RAIN_interrupt_Interrupt);

void RAIN_interrupt_SetVector(cyisraddress address);
cyisraddress RAIN_interrupt_GetVector(void);

void RAIN_interrupt_SetPriority(uint8 priority);
uint8 RAIN_interrupt_GetPriority(void);

void RAIN_interrupt_Enable(void);
uint8 RAIN_interrupt_GetState(void);
void RAIN_interrupt_Disable(void);

void RAIN_interrupt_SetPending(void);
void RAIN_interrupt_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the RAIN_interrupt ISR. */
#define RAIN_interrupt_INTC_VECTOR            ((reg32 *) RAIN_interrupt__INTC_VECT)

/* Address of the RAIN_interrupt ISR priority. */
#define RAIN_interrupt_INTC_PRIOR             ((reg32 *) RAIN_interrupt__INTC_PRIOR_REG)

/* Priority of the RAIN_interrupt interrupt. */
#define RAIN_interrupt_INTC_PRIOR_NUMBER      RAIN_interrupt__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable RAIN_interrupt interrupt. */
#define RAIN_interrupt_INTC_SET_EN            ((reg32 *) RAIN_interrupt__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the RAIN_interrupt interrupt. */
#define RAIN_interrupt_INTC_CLR_EN            ((reg32 *) RAIN_interrupt__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the RAIN_interrupt interrupt state to pending. */
#define RAIN_interrupt_INTC_SET_PD            ((reg32 *) RAIN_interrupt__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the RAIN_interrupt interrupt. */
#define RAIN_interrupt_INTC_CLR_PD            ((reg32 *) RAIN_interrupt__INTC_CLR_PD_REG)



#endif /* CY_ISR_RAIN_interrupt_H */


/* [] END OF FILE */
